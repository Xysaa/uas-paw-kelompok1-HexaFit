import { useState, useEffect } from 'react'

// Import komponen-komponen yang sudah dipisah
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import ClassCard from './components/ClassCard'
import Footer from './components/Footer'
import LoadingSpinner from './components/LoadingSpinner'
import ErrorMessage from './components/ErrorMessage'
import Login from './components/Login'        
import Register from './components/Register'  

function App() {
  // --- 1. STATE MANAGEMENT (PENGATUR DATA) ---
  const [user, setUser] = useState(null); // Menyimpan data user yg login (null = belum login)
  const [currentPage, setCurrentPage] = useState('home'); // 'home', 'login', 'register'
  
  const [classes, setClasses] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // --- 2. AUTHENTICATION HANDLERS ---
  const handleLogin = (userData) => {
    setUser(userData);
    setCurrentPage('home'); // Redirect ke home setelah login
  };

  const handleLogout = () => {
    // Hapus token dari localStorage
    localStorage.removeItem('gym_token');
    setUser(null);
    setCurrentPage('login'); // Redirect ke login setelah logout
  };

  const navigateTo = (page) => {
    setCurrentPage(page);
  }

  // --- 3. CHECK AUTH & FETCH DATA ---
  
  // Fungsi untuk cek apakah user sudah login sebelumnya (Persistent Session)
  const checkAuth = async () => {
    const token = localStorage.getItem('gym_token');
    if (token) {
      try {
        // Panggil endpoint /api/auth/me untuk validasi token & ambil data user
        // Pastikan endpoint ini ada di backend (routes.py: config.add_route('auth_me', '/api/auth/me'))
        const response = await fetch('http://localhost:6543/api/auth/me', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        
        if (response.ok) {
          const userData = await response.json();
          setUser(userData);
        } else {
          // Jika token expired/invalid, hapus
          localStorage.removeItem('gym_token');
        }
      } catch (err) {
        console.error("Gagal validasi sesi:", err);
      }
    }
  };

  const fetchClasses = async () => {
    setIsLoading(true);
    setError(null);

    try {
      // Mengambil data kelas dari endpoint API backend
      // Sesuaikan dengan routes.py: config.add_route("classes_list_create", "/api/classes")
      const response = await fetch('http://localhost:6543/api/classes');
      
      if (!response.ok) {
        // Jika endpoint belum siap, gunakan fallback ke mock data (untuk development)
        console.warn("API Classes belum siap/gagal, menggunakan Mock Data");
        await new Promise(resolve => setTimeout(resolve, 1000)); // Simulasi delay
        
        const mockData = [
          { id: 1, name: 'Body Pump', instructor: 'Coach Budi', schedule: 'Senin, 19:00', description: 'Latihan beban seluruh tubuh.' },
          { id: 2, name: 'Yoga Zen', instructor: 'Coach Siti', schedule: 'Selasa, 08:00', description: 'Tenangkan pikiran dan latih kelenturan.' },
          { id: 3, name: 'Crossfit Hardcore', instructor: 'Coach Ade', schedule: 'Rabu, 20:00', description: 'Latihan intensitas tinggi.' },
        ];
        setClasses(mockData);
        return; 
      }

      const data = await response.json();
      setClasses(data);

    } catch (err) {
      console.error("Gagal mengambil data kelas:", err);
      // Gunakan mock data jika server mati total (biar UI tetap tampil saat dev)
      const mockData = [
          { id: 1, name: 'Body Pump', instructor: 'Coach Budi', schedule: 'Senin, 19:00', description: 'Latihan beban seluruh tubuh.' },
          { id: 2, name: 'Yoga Zen', instructor: 'Coach Siti', schedule: 'Selasa, 08:00', description: 'Tenangkan pikiran dan latih kelenturan.' },
          { id: 3, name: 'Crossfit Hardcore', instructor: 'Coach Ade', schedule: 'Rabu, 20:00', description: 'Latihan intensitas tinggi.' },
      ];
      setClasses(mockData);
      // setError("Gagal terhubung ke server."); // Uncomment jika ingin strict error
    } finally {
      setIsLoading(false);
    }
  };

  // Jalankan cek auth & fetch data saat aplikasi pertama kali dimuat
  useEffect(() => {
    const initApp = async () => {
      await checkAuth();
      await fetchClasses();
    };
    initApp();
  }, []);


  // --- 4. RENDER PAGE LOGIC ---

  // Jika user memilih halaman LOGIN
  if (currentPage === 'login') {
    return <Login onLogin={handleLogin} onSwitchToRegister={() => navigateTo('register')} />;
  }

  // Jika user memilih halaman REGISTER
  if (currentPage === 'register') {
    return <Register onSwitchToLogin={() => navigateTo('login')} />;
  }

  // --- HALAMAN UTAMA (HOME) ---
  
  if (isLoading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} onRetry={fetchClasses} />;

  return (
    <div className="min-h-screen bg-gym-black font-sans text-white flex flex-col">
      
      {/* Navbar: Kirim props user & handler navigasi */}
      <Navbar 
        user={user} 
        onLogout={handleLogout} 
        onNavigateLogin={() => navigateTo('login')} 
      />
      
      <Hero />

      <main className="flex-grow">
        <div id="classes" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          
          <div className="flex items-end justify-between mb-12 border-b border-gray-800 pb-4">
            <div>
              <h2 className="text-3xl font-bold text-white uppercase tracking-wide">
                Kelas <span className="text-gym-green">Tersedia</span>
              </h2>
              <p className="text-gray-500 mt-2">
                {user ? `Halo, ${user.name}! Pilih kelasmu hari ini.` : 'Silakan Login untuk booking kelas.'}
              </p>
            </div>
            <span className="bg-gray-800 text-xs px-3 py-1 rounded-full text-gray-300 hidden sm:block border border-gray-700">
              Total: <span className="text-gym-green font-bold">{classes.length}</span> Kelas
            </span>
          </div>
          
          {classes.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {classes.map((cls) => (
                <ClassCard key={cls.id} cls={cls} />
              ))}
            </div>
          ) : (
            <div className="text-center py-10 text-gray-500">
              Belum ada kelas yang tersedia saat ini.
            </div>
          )}

        </div>
      </main>
      
      <Footer />
    </div>
  )
}

export default App
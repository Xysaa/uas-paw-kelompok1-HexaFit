import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';

// Import komponen UI error & loading punya kamu
import ErrorMessage from '../components/ui/ErrorMessage';     // Sesuaikan path folder
import LoadingSpinner from '../components/ui/LoadingSpinner'; // Sesuaikan path folder

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      // Simulasi fetch API (Ganti URL sesuai backend kamu)
      const response = await fetch('http://localhost:6543/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      
      const data = await response.json();
      
      if (!response.ok) throw new Error(data.message || 'Gagal Login');

      localStorage.setItem('token', data.token);
      navigate('/dashboard');

    } catch (err) {
      // Logic error ada di sini (Page)
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  // 1. Jika sedang loading, tampilkan komponen LoadingSpinner (Full Screen)
  if (isLoading) {
    return <LoadingSpinner />;
  }

  // 2. Jika ada Error fatal yang butuh tombol retry, tampilkan ErrorMessage
  // (Opsional: Kalau mau errornya full screen menutupi form)
  if (error === 'Network Error') { // Contoh kondisi
     return <ErrorMessage message={error} onRetry={() => setError('')} />;
  }

  return (
    <div className="min-h-screen bg-gym-black flex items-center justify-center px-4 relative overflow-hidden">
      <div className="max-w-md w-full bg-zinc-900 border border-zinc-800 rounded-xl p-8 shadow-lg relative z-10">
        
        <div className="text-center mb-8">
          <h2 className="text-3xl font-black text-white italic">
            LOGIN <span className="text-gym-green">IRONGYM</span>
          </h2>
        </div>

        {/* 3. Tampilkan Error kecil di dalam form menggunakan styling alert sederhana */}
        {/* Atau bisa juga menggunakan ErrorMessage tapi dimodifikasi CSS-nya biar ga full screen */}
        {error && (
          <div className="mb-4 p-3 bg-red-900/30 border border-red-500 rounded text-red-200 text-sm text-center">
             {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <Input 
            label="Email" 
            type="email" 
            value={email} 
            onChange={(e) => setEmail(e.target.value)} 
          />
          <Input 
            label="Password" 
            type="password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
          />
          
          {/* Tombol Login */}
          <Button type="submit">MASUK</Button>
        </form>
      </div>
    </div>
  );
};

export default Login;